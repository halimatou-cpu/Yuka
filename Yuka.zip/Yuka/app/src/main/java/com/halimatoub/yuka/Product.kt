package com.halimatoub.yuka

import java.net.URL

data class Product( val name:String,
                    val brand: String,
                    val codeBarre: Int,
                    val nutriscore: String,
                    val imageUrl: URL,
                    val quantity: String,
                    val countries: Array<String>,
                    val ingredientList: Array<String>,
                    val allergenSubstancesList: Array<String>,
                    val additvesList: Array<String>,

) {





}