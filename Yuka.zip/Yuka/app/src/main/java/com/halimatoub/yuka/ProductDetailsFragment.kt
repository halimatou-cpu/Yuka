package com.halimatoub.yuka

import androidx.fragment.app.Fragment

class ProductDetailsFragment: Fragment() {
}